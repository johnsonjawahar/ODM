package com.acme.trafficsim;

import java.util.List;

public class TrafficZone {
	
	private String name;
	private int numberOfCars;
	private int numberOfCollisions;
	private String trafficDensity;
	private String type;
	private String status;
	private int speedLimit;
	private double latitude;
	private double longitude;
	private List<String> vehicles;
	private List<String> collisions;

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getName() {
		return name;
	}

	public String getType() {
		return type;
	}


	public int getNumberOfCars() {
		return numberOfCars;
	}

	public String getTrafficDensity() {
		return trafficDensity;
	}
	public void setTrafficDensity(String trafficDensity) {
		this.trafficDensity = trafficDensity;
	}
	public int getSpeedLimit() {
		return speedLimit;
	}
	public void setSpeedLimit(int speedLimit) {
		this.speedLimit = speedLimit;
	}
	public List<String> getVehicles() {
		return vehicles;
	}
	public List<String> getCollisions() {
		return collisions;
	}
	public int getNumberOfCollisions() {
		return numberOfCollisions;
	}
	public double getLatitude() {
		return latitude;
	}
	public double getLongitude() {
		return longitude;
	}
	
}
