package com.acme.trafficsim;

import java.util.HashMap;

public class Vehicle {
	private String type = "car";
	private double lat;
	private double lng;
	private double speed;
	private double expectedSpeed;

	private HashMap<String, Object> customProps = new HashMap<String, Object>();
	
	private String id;
	private String name;
	private String state = "normal";
	private String description = "I am a connected car";
	

	private double heading = 0;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getLat() {
		return lat;
	}
	public void setLat(double latitude) {
		this.lat = latitude;
	}
	public double getLng() {
		return lng;
	}
	public void setLng(double longitude) {
		this.lng = longitude;
	}
	public double getSpeed() {
		return speed;
	}
	public void setSpeed(double speed) {
		this.speed = speed;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Vehicle() {
		super();
	}
	public double getHeading() {
		return heading;
	}
	public void setHeading(double heading) {
		this.heading = heading;
	}
	public HashMap<String, Object> getCustomProps() {
		return customProps;
	}
	public void setCustomProps(HashMap<String, Object> customProps) {
		this.customProps = customProps;
	}

	public double getExpectedSpeed() {
		return expectedSpeed;
	}
	public void setExpectedSpeed(double expectedSpeed) {
		this.expectedSpeed = expectedSpeed;
	}
}
